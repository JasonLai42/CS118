#ifndef helperfunc_hpp
#define helperfunc_hpp


unsigned short gen_seq();

unsigned short wrap_seq_ack(unsigned short num);

double start_timer();

double get_elapsed(double s);

#endif